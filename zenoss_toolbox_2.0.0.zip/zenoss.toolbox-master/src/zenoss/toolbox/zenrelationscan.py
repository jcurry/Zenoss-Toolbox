##############################################################################
#
# Copyright (C) Zenoss, Inc. 2016, all rights reserved.
#
# This content is made available according to terms specified in
# License.zenoss under the directory where your Zenoss product is installed.
#
##############################################################################
#!/opt/zenoss/bin/python

scriptVersion = "2.0.0"
scriptSummary = " - scans ZODB object ZenRelations for issues - "
documentationURL = "https://support.zenoss.com/hc/en-us/articles/203121165"


import argparse
import datetime
import Globals
import logging
import os
import sys
import time
import traceback
import transaction
import ZenToolboxUtils

from Products.CMFCore.utils import getToolByName
from Products.ZenUtils.Utils import getAllConfmonObjects
from Products.ZenUtils.ZenScriptBase import ZenScriptBase
from Products.Zuul.catalog.events import IndexingEvent
from time import localtime, strftime
from ZenToolboxUtils import inline_print
from ZODB.POSException import POSKeyError
from ZODB.transact import transact
from zope.event import notify


def progress_bar(items, errors, repairs, fix_value):
    if fix_value:
        inline_print("[%s]  | Items Scanned: %12d | Errors:  %6d | Repairs: %6d |  " %
                     (time.strftime("%Y-%m-%d %H:%M:%S"), items, errors, repairs))
    else:
        inline_print("[%s]  | Items Scanned: %12d | Errors:  %6d |  " % (time.strftime("%Y-%m-%d %H:%M:%S"), items, errors))


def scan_relationships(attempt_fix, max_cycles, use_unlimited_memory, dmd, log, counters):
    '''Scan through zodb relationships looking for broken references'''

#    ENTIRETY OF REBUILD CODE FROM ZenUtils/CheckRelations.py (for reference)
#    def rebuild(self):
#        repair = self.options.repair
#        ccount = 0
#        for object in getAllConfmonObjects(self.dmd):
#            ccount += 1
#            self.log.debug("checking relations on object %s"
#                                % object.getPrimaryDmdId())
#            object.checkRelations(repair=repair)
#            ch = object._p_changed
#            if not ch: object._p_deactivate()
#            if ccount >= self.options.savepoint:
#                transaction.savepoint()
#                ccount = 0
#        if self.options.nocommit:
#            self.log.info("not commiting any changes")
#        else:
#            trans = transaction.get()
#            trans.note('CheckRelations cleaned relations' )
#            trans.commit()

    PROGRESS_INTERVAL = 829  # Prime number near 1000 ending in a 9, used for progress bar

    print("[%s] Examining ZenRelations...\n" % (time.strftime("%Y-%m-%d %H:%M:%S")))
    log.info("Examining ZenRelations...")

    number_of_issues = -1
    current_cycle = 0
    if not attempt_fix:
        max_cycles = 1

    progress_bar(counters['item_count'].value(), counters['error_count'].value(),
                         counters['repair_count'].value(), attempt_fix)

    while ((current_cycle < max_cycles) and (number_of_issues != 0)):
        number_of_issues = 0
        current_cycle += 1
        if (attempt_fix):
            log.info("Beginning cycle %d" % (current_cycle))

        try:
            relationships_to_check = getAllConfmonObjects(dmd)
        except Exception:
            raise

        while True:
            try:
                object = relationships_to_check.next()
                counters['item_count'].increment()

                if (counters['item_count'].value() % PROGRESS_INTERVAL) == 0:
                    if not use_unlimited_memory:
                        transaction.abort()
                    progress_bar(counters['item_count'].value(), counters['error_count'].value(),
                                 counters['repair_count'].value(), attempt_fix)
                    log.debug("Processed %d items" % (counters['item_count'].value()))

                try:
                    object.checkRelations(repair=attempt_fix)
                    changed = object._p_changed
                    if not changed:
                        object._p_deactivate()
                    else:
                        transaction.commit()
                    log.debug("Checked object %s" % (object.getPrimaryDmdId()))
                except Exception as e:
                    log.exception(e)
                    counters['error_count'].increment()
                    counters['repair_count'].increment()
                except:
                    try:
                        log.error("Object %s had broken relationship" % (object.getPrimaryDmdId()))
                    except:
                        log.error("Object had issues loading - PKE")
                    counters['error_count'].increment()
                    counters['repair_count'].increment()

            except StopIteration:
                break
            except Exception as e:
                log.exception(e)
                if not use_unlimited_memory:
                    transaction.abort()
                progress_bar(counters['item_count'].value(), counters['error_count'].value(),
                             counters['repair_count'].value(), attempt_fix)
                print("\n\n#################################################################")
                print "CRITICAL: Exception encountered - aborting.  Please see log file."
                print("#################################################################")
                return

    if not use_unlimited_memory:
        transaction.abort()
    progress_bar(counters['item_count'].value(), counters['error_count'].value(),
                 counters['repair_count'].value(), attempt_fix)
    print


def main():
    '''Scans zodb objects for ZenRelations issues.  If --fix, attempts repair.'''

    execution_start = time.time()
    scriptName = os.path.basename(__file__).split('.')[0]
    parser = ZenToolboxUtils.parse_options(scriptVersion, scriptName + scriptSummary + documentationURL)
    # Add in any specific parser arguments for %scriptName
    parser.add_argument("-f", "--fix", action="store_true", default=False,
                        help="attempt to remove any invalid references")
    parser.add_argument("-n", "--cycles", action="store", default="2", type=int,
                        help="maximum times to cycle (with --fix)")
    parser.add_argument("-u", "--unlimitedram", action="store_true", default=False,
                        help="skip transaction.abort() - unbounded RAM, ~40%% faster")
    cli_options = vars(parser.parse_args())
    log, logFileName = ZenToolboxUtils.configure_logging(scriptName, scriptVersion, cli_options['tmpdir'])
    log.info("Command line options: %s" % (cli_options))
    if cli_options['debug']:
        log.setLevel(logging.DEBUG)

    print "\n[%s] Initializing %s v%s (detailed log at %s)" % \
          (time.strftime("%Y-%m-%d %H:%M:%S"), scriptName, scriptVersion, logFileName)

    # Attempt to get the zenoss.toolbox lock before any actions performed
    if not ZenToolboxUtils.get_lock("zenoss.toolbox", log):
        sys.exit(1)

    # Obtain dmd ZenScriptBase connection
    dmd = ZenScriptBase(noopts=True, connect=True).dmd
    log.debug("ZenScriptBase connection obtained")

    counters = {
        'item_count': ZenToolboxUtils.Counter(0),
        'error_count': ZenToolboxUtils.Counter(0),
        'repair_count': ZenToolboxUtils.Counter(0)
        }

    scan_relationships(cli_options['fix'], cli_options['cycles'], cli_options['unlimitedram'], dmd, log, counters)

    if not cli_options['skipEvents']:
        if counters['error_count'].value():
            eventSeverity = 4
            eventSummaryMsg = "%s encountered %d errors (took %1.2f seconds)" % \
                               (scriptName, counters['error_count'].value(), (time.time() - execution_start))
        else:
            eventSeverity = 2
            eventSummaryMsg = "%s completed without errors (took %1.2f seconds)" % \
                               (scriptName, (time.time() - execution_start))

        ZenToolboxUtils.send_summary_event(
            eventSummaryMsg, eventSeverity,
            scriptName, "executionStatus",
            documentationURL, dmd
        )

    # Print final status summary, update log file with termination block
    log.info("zenrelationscan examined %d objects, encountered %d errors, and attempted %d repairs",
             counters['item_count'].value(), counters['error_count'].value(), counters['repair_count'].value())
    print("\n[%s] Execution finished in %s\n" % (strftime("%Y-%m-%d %H:%M:%S", localtime()),
           datetime.timedelta(seconds=int(time.time() - execution_start))))
    log.info("zenrelationscan completed in %1.2f seconds" % (time.time() - execution_start))
    log.info("############################################################")

    if ((counters['error_count'].value() > 0) and not cli_options['fix']):
        print("** WARNING ** Issues were detected - Consult KB article at")
        print("      https://support.zenoss.com/hc/en-us/articles/203121165\n")
        sys.exit(1)
    else:
        sys.exit(0)


if __name__ == "__main__":
    main()
